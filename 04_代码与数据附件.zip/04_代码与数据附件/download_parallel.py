"""Resume large public files using verified standard HTTP byte ranges."""
import concurrent.futures,datetime as dt,hashlib,json,time,urllib.request
from pathlib import Path
from crawler import ROOT,RAW,LOGS,utc,save_meta
sizes={'06':490819474,'07':487222980,'08':479574607}
chunk=8*1024*1024
tasks=[];prefixes={}
parts=ROOT/'temp/download_parts';parts.mkdir(parents=True,exist_ok=True)
for m,size in sizes.items():
    file=f'fhvhv_tripdata_2025-{m}.parquet';final=RAW/'tlc'/file
    if final.exists() and final.stat().st_size==size:continue
    prefix=final.with_suffix('.parquet.partial')
    n=(prefix.stat().st_size//chunk)*chunk if prefix.exists() else 0
    prefixes[m]=n
    for start in range(n,size,chunk):tasks.append((m,start,min(start+chunk,size)-1,size))
def one(job):
    m,start,end,size=job;dest=parts/f'{m}_{start}_{end}.part';mp=dest.with_suffix('.json')
    if dest.exists() and mp.exists() and dest.stat().st_size==end-start+1:return
    url=f'https://d37ci6vzurychx.cloudfront.net/trip-data/fhvhv_tripdata_2025-{m}.parquet'
    meta={'url':url,'started_at':utc(),'start':start,'end':end}
    for attempt in range(4):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'Range':f'bytes={start}-{end}'}),timeout=120) as r:
                body=r.read();assert r.status==206;assert r.headers['Content-Range']==f'bytes {start}-{end}/{size}'
            assert len(body)==end-start+1
            dest.write_bytes(body);meta.update(status='verified',bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),completed_at=utc())
            save_meta(mp,meta);print(m,start,len(body),'verified',flush=True);return
        except Exception as exc:
            meta['last_error']=str(exc);time.sleep(min(30,2**attempt*2))
    save_meta(mp,{**meta,'status':'failed'});raise RuntimeError(f'Failed range {job}')
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(one,tasks))
for m,n in prefixes.items():
    name=f'fhvhv_tripdata_2025-{m}.parquet';final=RAW/'tlc'/name;merged=final.with_suffix('.parquet.merging')
    sha=hashlib.sha256()
    with merged.open('wb') as f:
        if n:
            with final.with_suffix('.parquet.partial').open('rb') as p:
                left=n
                while left:
                    b=p.read(min(chunk,left));assert b;f.write(b);sha.update(b);left-=len(b)
        for start in range(n,sizes[m],chunk):
            end=min(start+chunk,sizes[m])-1;b=(parts/f'{m}_{start}_{end}.part').read_bytes()
            assert len(b)==end-start+1;f.write(b);sha.update(b)
    assert merged.stat().st_size==sizes[m]
    with merged.open('rb') as f:assert f.read(4)==b'PAR1';f.seek(-4,2);assert f.read()==b'PAR1'
    merged.replace(final)
    save_meta(LOGS/('tlc_'+name+'.json'),{'source':'tlc','url':f'https://d37ci6vzurychx.cloudfront.net/trip-data/{name}',
       'path':str(final.relative_to(ROOT)),'bytes':sizes[m],'sha256':sha.hexdigest(),'status':'verified','completed_at':utc(),
       'resumed_prefix_bytes':n,'note':'Range parts and interrupted prefixes are not separately counted toward raw data volume.'})
    print('COMPLETE',m,sizes[m],sha.hexdigest(),flush=True)
