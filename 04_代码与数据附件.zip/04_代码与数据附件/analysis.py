"""Evidence analysis from integrated observations. No simulated data are used."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
df=pd.read_csv(ROOT/'data/integrated/borough_day.csv',parse_dates=['date'])
assert len(df)==460 and df[['date','borough']].duplicated().sum()==0
city=df.groupby('date',as_index=False).agg(fhv_trips=('fhv_trips','sum'),rail_entries=('rail_entries','sum'),base_fare_usd=('base_fare_usd','sum'),fare_trips=('fare_trips','sum'),temperature_c=('temperature_2m_mean','first'),precipitation_mm=('precipitation_sum','first'))
city['mean_base_fare']=city.base_fare_usd/city.fare_trips
city['weekday']=city.date.dt.dayofweek;city['month']=city.date.dt.month
city['rainy']=city.precipitation_mm>=1
city['weekend']=city.weekday>=5
for var in ['fhv_trips','rail_entries','mean_base_fare']:
    city[var+'_index']=100*city[var]/city[var].mean()
    groupmean=city.groupby('weekday')[var].transform('mean')
    city[var+'_weekday_index']=100*city[var]/groupmean
city.to_csv(ROOT/'analysis/city_day.csv',index=False)
corr=float(city.fhv_trips.corr(city.rail_entries))
weekday_corr=float(city.fhv_trips_weekday_index.corr(city.rail_entries_weekday_index))

# Inference unit is a calendar day. Borough replication does not inflate the weather sample size.
# Log outcome ~ precipitation (per 10mm), temperature + weekday fixed effects + month fixed effects.
controls=pd.get_dummies(city[['weekday','month']].astype('category'),drop_first=True,dtype=float)
X=np.column_stack([np.ones(len(city)),city.precipitation_mm.to_numpy()/10,city.temperature_c.to_numpy(),controls.to_numpy()])
names=['intercept','precipitation_per10mm','temperature_c']+list(controls.columns)
assert np.linalg.matrix_rank(X)==X.shape[1]
rng=np.random.default_rng(20251112);B=2000;n=len(city);block=7
boot_indices=[]
for b in range(B):
    starts=rng.integers(0,n,size=int(np.ceil(n/block)))
    boot_indices.append(np.concatenate([(np.arange(s,s+block)%n) for s in starts])[:n])
models=[]
for outcome in ['fhv_trips','rail_entries','mean_base_fare']:
    y=np.log(city[outcome].to_numpy());beta=np.linalg.lstsq(X,y,rcond=None)[0]
    preds=X@beta;resid=y-preds
    draws=[]
    for idx in boot_indices:
        if np.linalg.matrix_rank(X[idx])<X.shape[1]:continue
        draws.append(np.linalg.lstsq(X[idx],y[idx],rcond=None)[0][1:3])
    draws=np.asarray(draws);low,high=np.quantile(draws,[.025,.975],axis=0)
    result={'outcome':outcome,'n_days':n,'r_squared':float(1-np.sum(resid**2)/np.sum((y-y.mean())**2)),'bootstrap_valid':len(draws)}
    for j,term in enumerate(['rain_per10mm','temperature_per1c']):
        result.update({term+'_pct':float(100*np.expm1(beta[j+1])),term+'_low_pct':float(100*np.expm1(low[j])),term+'_high_pct':float(100*np.expm1(high[j]))})
    models.append(result)
pd.DataFrame(models).to_csv(ROOT/'analysis/weather_models.csv',index=False)

# Transparent K-means implementation for 92 observed city-days, no external model service.
features=['fhv_trips','rail_entries','mean_base_fare','temperature_c','precipitation_mm']
F=city[features].to_numpy(float);F[:,0:2]=np.log(F[:,0:2]);F[:,4]=np.log1p(F[:,4])
mu=F.mean(axis=0);sd=F.std(axis=0,ddof=0);Z=(F-mu)/sd
def fit_kmeans(Z,k,seed):
    rng=np.random.default_rng(seed);centers=Z[rng.choice(len(Z),k,replace=False)].copy()
    for iteration in range(300):
        labels=((Z[:,None]-centers[None,:])**2).sum(axis=2).argmin(axis=1)
        updated=np.vstack([Z[labels==j].mean(axis=0) if np.any(labels==j) else Z[rng.integers(len(Z))] for j in range(k)])
        if np.max(abs(updated-centers))<1e-8:break
        centers=updated
    inertia=float(((Z-centers[labels])**2).sum())
    return labels,centers,inertia
distance=np.sqrt(((Z[:,None]-Z[None,:])**2).sum(axis=2))
def silhouette(labels):
    vals=[]
    for i in range(len(labels)):
        same=np.flatnonzero(labels==labels[i]);same=same[same!=i]
        if not len(same):vals.append(0);continue
        a=distance[i,same].mean();b=min(distance[i,labels==j].mean() for j in np.unique(labels) if j!=labels[i]);vals.append((b-a)/max(a,b))
    return float(np.mean(vals))
choices=[];candidates={}
for k in [2,3,4,5]:
    fits=[fit_kmeans(Z,k,20251112+i) for i in range(40)];best=min(fits,key=lambda r:r[2]);s=silhouette(best[0]);choices.append({'k':k,'silhouette':s,'inertia':best[2]});candidates[k]=best
selected=max(choices,key=lambda x:x['silhouette'])['k'];labels,centers,_=candidates[selected]
# Stable cluster numbering by mean observed rail ridership, not arbitrary algorithm labels.
order=sorted(range(selected),key=lambda j:city.loc[labels==j,'rail_entries'].mean());remap={old:new+1 for new,old in enumerate(order)}
city['cluster']=[remap[int(x)] for x in labels]
profiles=city.groupby('cluster').agg(days=('date','size'),fhv_trips=('fhv_trips','mean'),rail_entries=('rail_entries','mean'),mean_base_fare=('mean_base_fare','mean'),temperature_c=('temperature_c','mean'),precipitation_mm=('precipitation_mm','mean'),weekend_share=('weekend','mean'))
city.to_csv(ROOT/'analysis/city_day.csv',index=False);profiles.to_csv(ROOT/'analysis/cluster_profiles.csv');pd.DataFrame(choices).to_csv(ROOT/'analysis/cluster_selection.csv',index=False)
def ari(a,b):
    table=np.zeros((max(a)+1,max(b)+1),dtype=int)
    for x,y in zip(a,b):table[x,y]+=1
    comb=lambda x: x*(x-1)/2
    cross=comb(table).sum();ra=comb(table.sum(axis=1)).sum();rb=comb(table.sum(axis=0)).sum();tot=comb(len(a));exp=ra*rb/tot;den=(ra+rb)/2-exp
    return float((cross-exp)/den) if den else 1.0
stability=[ari(labels,fit_kmeans(Z,selected,20260101+i)[0]) for i in range(40)]

borough=df.groupby('borough').agg(days=('date','size'),fhv_trips=('fhv_trips','sum'),rail_entries=('rail_entries','sum'),base_fare_usd=('base_fare_usd','sum'),fare_trips=('fare_trips','sum'),population=('population_2024','first'))
borough['daily_fhv_per1000']=1000*borough.fhv_trips/borough.population/borough.days
borough['daily_rail_per1000']=1000*borough.rail_entries/borough.population/borough.days
borough['mean_base_fare']=borough.base_fare_usd/borough.fare_trips
borough['fare_share_pct']=100*borough.base_fare_usd/borough.base_fare_usd.sum()
borough.to_csv(ROOT/'analysis/borough_summary.csv')
weekday=city.groupby('weekday').agg(fhv_trips=('fhv_trips','mean'),rail_entries=('rail_entries','mean'),mean_base_fare=('mean_base_fare','mean'))
weekday.to_csv(ROOT/'analysis/weekday_summary.csv')
rain=city.groupby('rainy').agg(days=('date','size'),fhv_trips=('fhv_trips','mean'),rail_entries=('rail_entries','mean'),mean_base_fare=('mean_base_fare','mean'))
rain.to_csv(ROOT/'analysis/rain_descriptive.csv')
summary={'n_days':len(city),'n_borough_days':len(df),'fhv_trips':int(city.fhv_trips.sum()),'rail_entries':float(city.rail_entries.sum()),'base_fare_usd':float(city.base_fare_usd.sum()),'mean_base_fare':float(city.base_fare_usd.sum()/city.fare_trips.sum()),'daily_raw_correlation':corr,'daily_weekday_adjusted_correlation':weekday_corr,
         'selected_k':selected,'silhouette':next(c['silhouette'] for c in choices if c['k']==selected),'kmeans_seed_runs':40,'cluster_stability_median_ari':float(np.median(stability)),'cluster_stability_min_ari':float(min(stability)),
         'weather_model_unit':'92 city-days, not 460 independent weather observations','bootstrap':'2000 circular moving-block resamples, block length 7 days, 95% percentile intervals',
         'cluster_features':features,'cluster_transform':'log trip/entry counts and log1p precipitation, then z-score; other variables z-score',
         'fare_threshold_sensitivity_max_borough_day_abs_change':float((df.mean_base_fare-df.mean_fare_le1000).abs().max()),
         'limits':['Associations only; no causal claim','Residents are normalization denominators; trips may be made by commuters or visitors','MTA dataset covers subway, SIR and Roosevelt Island Tram, and records paid system entries, not unique people','Base fare excludes taxes, tips, tolls and other fees','Weather is a single city coordinate ERA5 reanalysis proxy','Summer 2025 observations cannot establish annual patterns']}
(ROOT/'analysis/results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
