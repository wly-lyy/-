"""Verify real source files and package evidence before publishing any result."""
from pathlib import Path
import csv,hashlib,json,datetime as dt
ROOT=Path(__file__).parent
MAN=ROOT/'metadata';MAN.mkdir(exist_ok=True)
def hashfile(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
rows=[]
for p in sorted((ROOT/'logs').glob('*.json')):
    j=json.loads(p.read_text(encoding='utf-8'))
    if j.get('status')!='verified' or j.get('source') not in ['tlc','mta']:continue
    target=ROOT/Path(j['path'].replace('\\','/'));assert target.exists()
    assert target.stat().st_size==j['bytes'];assert hashfile(target)==j['sha256']
    rows.append({'source':j['source'],'relative_path':target.relative_to(ROOT).as_posix(),'bytes':j['bytes'],'sha256':j['sha256'],'url':j['url'],'completed_at':j.get('completed_at'),'records':j.get('rows','')})
primary={'tlc':sum(r['bytes'] for r in rows if r['source']=='tlc'),'mta':sum(r['bytes'] for r in rows if r['source']=='mta')}
assert sum(r['source']=='tlc' for r in rows)==3
assert sum(r['source']=='mta' for r in rows)==92
assert all(v>=200_000_000 for v in primary.values())
total=sum(primary.values());assert total>=2*1024**3;assert max(primary.values())/total<=.8
aux=[('census','data/raw/census/co-est2024-alldata.csv'),('census','data/raw/census/cb_2024_us_county_500k.zip'),('weather','data/raw/weather/nyc_2025_summer.json'),('tlc_aux','data/raw/tlc/taxi_zone_lookup.csv'),('tlc_aux','data/raw/tlc/taxi_zones.zip')]
for source,rel in aux:
    p=ROOT/rel;assert p.exists();rows.append({'source':source,'relative_path':rel,'bytes':p.stat().st_size,'sha256':hashfile(p),'url':'See data_sources.md and source_metadata.json','completed_at':'See source_metadata.json','records':''})
with (MAN/'raw_manifest.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'checked_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'major_sources':primary,'major_raw_bytes':total,'major_raw_decimal_GB':total/1e9,'major_raw_GiB':total/1024**3,
         'largest_source_share':max(primary.values())/total,'independent_source_families':['NYC TLC','MTA','ECMWF ERA5 via Open-Meteo','US Census Bureau'],
         'source_types':['Institutional transport transaction records in Parquet','Public API hourly spatiotemporal records in CSV','Meteorological reanalysis API JSON','Geospatial polygons and population statistics'],
         'main_data_files':95,'mta_days':92,'tlc_months':3,'auxiliary_sources_exempt_from_200MB':True,
         'volume_policy':'Count each original canonical source response once. MTA CSV is HTTP entity content after gzip transport decoding, unchanged. Exclude duplicate downloads, temporary byte-range parts, cleaned data, derived tables, charts, reference web pages and auxiliary full-US records from the 2GiB threshold.',
         'all_primary_hashes_rechecked':True,'source_share_check_passed':True,'minimum_2GiB_passed':True,'minimum_200MB_each_major_source_passed':True}
(MAN/'data_scale.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
