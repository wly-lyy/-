"""Download public auxiliary files and authoritative MTA daily counts, preserving provenance."""
import argparse,datetime as dt,hashlib,json,time,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SOURCES=[
 ('census_pop2024','data/raw/census/co-est2024-alldata.csv','https://www2.census.gov/programs-surveys/popest/datasets/2020-2024/counties/totals/co-est2024-alldata.csv'),
 ('census_geo2024','data/raw/census/cb_2024_us_county_500k.zip','https://www2.census.gov/geo/tiger/GENZ2024/shp/cb_2024_us_county_500k.zip'),
 ('nyc_weather_2025','data/raw/weather/nyc_2025_summer.json','https://archive-api.open-meteo.com/v1/archive?latitude=40.77898&longitude=-73.96925&start_date=2025-06-01&end_date=2025-08-31&daily=temperature_2m_mean,temperature_2m_max,precipitation_sum,wind_speed_10m_max&timezone=America%2FNew_York&models=era5'),
 ('tlc_zone_lookup','data/raw/tlc/taxi_zone_lookup.csv','https://d37ci6vzurychx.cloudfront.net/misc/taxi_zone_lookup.csv'),
 ('tlc_zones_shape','data/raw/tlc/taxi_zones.zip','https://d37ci6vzurychx.cloudfront.net/misc/taxi_zones.zip'),
 ('mta_daycounts','docs/mta_daycounts.json','https://data.ny.gov/resource/5wq4-mkjj.json?%24select=date_trunc_ymd%28transit_timestamp%29+as+day%2Ccount%28%2A%29+as+n&%24where=transit_timestamp+%3E%3D+%272025-06-01T00%3A00%3A00%27+AND+transit_timestamp+%3C+%272025-09-01T00%3A00%3A00%27&%24group=day&%24order=day&%24limit=1000')]
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--refresh',action='store_true');a=ap.parse_args()
    folder=ROOT/'metadata';folder.mkdir(exist_ok=True);meta_file=folder/'source_metadata.json'
    old=json.loads(meta_file.read_text(encoding='utf-8')) if meta_file.exists() else []
    known={m['id']:m for m in old};records=[]
    for sid,rel,url in SOURCES:
        p=ROOT/rel;p.parent.mkdir(parents=True,exist_ok=True)
        if p.exists() and sid in known and not a.refresh:
            assert hashlib.sha256(p.read_bytes()).hexdigest()==known[sid]['sha256'];records.append(known[sid]);continue
        with urllib.request.urlopen(url,timeout=120) as r:
            body=r.read();m={'id':sid,'requested_url':url,'final_url':r.url,'status':r.status,'content_type':r.headers.get('Content-Type')}
        p.write_bytes(body);m.update(path=rel,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),retrieved_at=dt.datetime.now(dt.timezone.utc).isoformat());records.append(m)
        print(sid,len(body),'verified',flush=True);time.sleep(.5)
    if old and a.refresh:
        history=ROOT/'logs/history';history.mkdir(parents=True,exist_ok=True)
        (history/('source_metadata_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S')+'.json')).write_text(json.dumps(old,indent=2),encoding='utf-8')
    meta_file.write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
if __name__=='__main__':main()
