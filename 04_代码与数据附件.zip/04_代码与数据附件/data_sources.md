# 数据来源、访问说明与追溯

所有实际采集发生于2026-11-12。机器记录使用UTC，纽约分析日期采用America/New_York，二者用途不同。独立来源按底层生产机构与生产过程归并，不按文件或网站数量拆分。

| 来源族 | 内容与获取方式 | 规模/形态 | 主要字段与联系 | 访问及使用说明 |
|---|---|---|---|---|
| NYC TLC，主要 | 官方公开Trip Record Data，2025年6/7/8月High Volume FHV直接下载 | 1,457,617,061字节，3个Parquet | 上下车时间、区域ID、基础车费；区划表映射行政区 | 公开机构业务记录；遵守NYC.gov Terms of Use，不暗示官方认可，不识别个人 |
| MTA，主要 | NY开放数据目录5wq4-mkjj，Socrata API，2025-06-01至08-31，逐日请求 | 1,386,466,904字节，92个CSV，8,066,644行 | transit_timestamp、borough、station_complex_id、ridership、经纬度 | OPEN-NY Terms允许合法复用；数据Overview注明目前无使用限制；遵守接口访问频率，不绕过限制 |
| ECMWF ERA5，经Open-Meteo，辅助 | 历史天气API固定纽约坐标，2025年夏季92日 | JSON，3,472字节 | 当地date、日均温度、日降水；日期关联 | Open-Meteo免费非商业教育用途；按其CC BY 4.0要求注明来源与处理。数据为ERA5再分析，非实测站点记录 |
| US Census Bureau，辅助 | 2024县人口估计CSV和2024县级边界ZIP | CSV与地理多边形，共13,395,248字节 | STATE/COUNTY、POPESTIMATE2024、GEOID；县区映射及车站点落区 | 官方公开统计与地理资料，保留来源和版本，未声称官方担保分析结果；全国范围文件仅抽取纽约五县，整体不计入2GB门槛 |

TLC查询表12,331字节及备用区域空间包1,022,574字节属于同一TLC来源；实际空间校验使用Census WGS84边界。备用空间包没有参与统计或规模门槛。

## 访问与采集方法

仅使用公开文件直链和开放API，无登录、验证码、付费墙、账号凭据或私有平台数据。TLC用标准HTTP Range、8个并发任务、长度与范围核验；MTA用6个并发日请求，使用标准HTTP gzip内容解码，不改变CSV格式。每个日文件比对官方查询计数，未达标文件重试；没有通过改写文本或转为更大格式凑规模。天气与人口/边界文件低频请求。服务返回拒绝或权限要求时不绕过；此前Census API要求密钥，因此改用其公开批量文件。

原始清单包含95个主要文件的实际URL、日期、字节数与SHA-256。辅助来源原始响应元数据在metadata/source_metadata.json。源可能修订历史数据，重新采集的文件须另立版本。

## 来源页面与字典

- TLC目录：https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page
- TLC字典：https://www.nyc.gov/assets/tlc/downloads/pdf/data_dictionary_trip_records_hvfhs.pdf
- TLC区划映射：https://d37ci6vzurychx.cloudfront.net/misc/taxi_zone_lookup.csv
- MTA目录：https://data.ny.gov/Transportation/MTA-Subway-Hourly-Ridership-Beginning-2025/5wq4-mkjj
- MTA目录元数据与附加字典：https://data.ny.gov/api/views/5wq4-mkjj.json
- Open-Meteo历史接口：https://open-meteo.com/en/docs/historical-weather-api
- Open-Meteo条款：https://open-meteo.com/en/terms
- OPEN-NY条款：https://data.ny.gov/dataset/OPEN-NY-Terms-Of-Use/77gx-ii52
- Census人口目录：https://www2.census.gov/programs-surveys/popest/datasets/2020-2024/counties/totals/
- Census边界：https://www2.census.gov/geo/tiger/GENZ2024/shp/cb_2024_us_county_500k.zip

Open-Meteo/ERA5署名：Weather data by Open-Meteo, based on ECMWF ERA5. 本项目进行当地日汇总连接、统计建模和图形展示，不暗示提供方认可结论。各源许可/条款分别适用，本项目不把所有第三方数据重新统一许可。

## 辅助来源实际记录

- census_pop2024：2026-11-12T02:08:15.789098+00:00；1,769,182字节；SHA-256 `abcc8720d669e793bbfdcd440eeec37a78db3b452adbe4ccd1eadf7c72b522b9`。
  URL：https://www2.census.gov/programs-surveys/popest/datasets/2020-2024/counties/totals/co-est2024-alldata.csv
- census_geo2024：2026-11-12T02:08:15.789098+00:00；11,626,066字节；SHA-256 `da4051717caec55c75e3748c3608c2a3dbde8d1ff401bbaf4f952e3c3fb63ef1`。
  URL：https://www2.census.gov/geo/tiger/GENZ2024/shp/cb_2024_us_county_500k.zip
- nyc_weather_2025：2026-11-12T02:08:32.608690+00:00；3,472字节；SHA-256 `447e664185662dc897932cb57e0b008a79d636f874a82261d41fcaddce97b239`。
  URL：https://archive-api.open-meteo.com/v1/archive?latitude=40.77898&longitude=-73.96925&start_date=2025-06-01&end_date=2025-08-31&daily=temperature_2m_mean,temperature_2m_max,precipitation_sum,wind_speed_10m_max&timezone=America%2FNew_York&models=era5
- tlc_zone_lookup：2026-11-12T02:01:24.481441+00:00；12,331字节；SHA-256 `1a99e105092230f8620f301edcca7f80d3080642ff404d28ed957d3fa222c8ed`。
  URL：https://d37ci6vzurychx.cloudfront.net/misc/taxi_zone_lookup.csv
- tlc_zones_shape：2026-11-12T02:08:34.057790+00:00；1,022,574字节；SHA-256 `f6d711917bb4340f8f644d5366c51665489eb2d426dd1a4a55677721ae5adf17`。
  URL：https://d37ci6vzurychx.cloudfront.net/misc/taxi_zones.zip
- mta_daycounts：2026-11-12T02:01:25.143129+00:00；4,325字节；SHA-256 `d92734922e42e14bfe61156d6553d9d11e46ed49f4a17a9a55a100a78c4f425d`。
  URL：https://data.ny.gov/resource/5wq4-mkjj.json?%24select=date_trunc_ymd%28transit_timestamp%29+as+day%2Ccount%28%2A%29+as+n&%24where=transit_timestamp+%3E%3D+%272025-06-01T00%3A00%3A00%27+AND+transit_timestamp+%3C+%272025-09-01T00%3A00%3A00%27&%24group=day&%24order=day&%24limit=1000

## 实际采集日志范围

logs下的JSON为实际运行或实际原始响应记录。完整性成功日志可追溯已计量文件；不是手工造出的拟采集计划。部分早期失败尝试仅保留在会话输出，未逐次归档，因而不声称日志覆盖每一次请求。后续重试历史与元数据更新会存于logs/history。
