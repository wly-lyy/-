"""Produce small real samples, schema and complete layer indexes; no synthetic rows."""
from pathlib import Path
import csv,json,duckdb
ROOT=Path(__file__).resolve().parent
c=duckdb.connect();schema={};index=[]
for layer in ['raw','cleaned']:
    sample=ROOT/f'data/{layer}/samples';sample.mkdir(exist_ok=True)
    paths=sorted((ROOT/f'data/{layer}/tlc').glob('*.parquet'))+sorted((ROOT/f'data/{layer}/mta').glob('*.parquet' if layer=='cleaned' else '*.csv'))
    for p in paths:
        kind=p.parent.name;reader='read_parquet' if p.suffix=='.parquet' else 'read_csv'
        desc=c.execute(f"DESCRIBE SELECT * FROM {reader}('{p.as_posix()}')").fetchall()
        schema.setdefault(layer+'_'+kind,[{'field':row[0],'type':row[1]} for row in desc])
        index.append({'layer':layer,'relative_path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sampling':'TLC each month first 100 rows; MTA first day each month first 100 rows'})
        if kind=='tlc' or p.stem in ['2025-06-01','2025-07-01','2025-08-01']:
            dest=sample/(kind+'_'+p.stem+'.csv')
            c.execute(f"COPY(SELECT * FROM {reader}('{p.as_posix()}') LIMIT 100) TO '{dest.as_posix()}' (HEADER)")
for p in (ROOT/'data/integrated').glob('*.csv'):
    desc=c.execute(f"DESCRIBE SELECT * FROM read_csv('{p.as_posix()}')").fetchall()
    schema[p.stem]=[{'field':row[0],'type':row[1]} for row in desc]
    index.append({'layer':'integrated','relative_path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sampling':'Full integrated table included'})
(ROOT/'metadata/schema.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2),encoding='utf-8')
with (ROOT/'metadata/layer_index.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(index[0]));w.writeheader();w.writerows(index)
for layer in ['raw','cleaned']:
    (ROOT/f'data/{layer}/INDEX.md').write_text('完整文件索引见 ../../metadata/layer_index.csv；原始文件校验见 ../../metadata/raw_manifest.csv。\n样本保留原始字段与真实行值；Parquet抽样以CSV展示，不计入原始规模。每月TLC前100行、每月首日MTA前100行，为便于核查的确定性样本，不代表随机或总体分布。完整层通过README指定命令重建。\n',encoding='utf-8')
print('Generated actual raw/cleaned samples, schemas and full indexes')
