"""Generate evidence figures from actual computed result tables."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager,colors
from matplotlib.patches import Polygon,FancyArrowPatch,Rectangle
ROOT=Path(__file__).parent;OUT=ROOT/'visualization';OUT.mkdir(exist_ok=True)
font=Path('C:/Windows/Fonts/msyh.ttc')
if font.exists():font_manager.fontManager.addfont(str(font));plt.rcParams['font.family']='Microsoft YaHei'
plt.rcParams.update({'font.size':11,'axes.titlesize':16,'axes.labelsize':11,'axes.spines.top':False,'axes.spines.right':False,'axes.unicode_minus':False,'savefig.dpi':180})
blue='#176B9C';orange='#DF7C30';green='#268678'
cn={'Bronx':'布朗克斯','Brooklyn':'布鲁克林','Manhattan':'曼哈顿','Queens':'皇后区','Staten Island':'史泰登岛'}
city=pd.read_csv(ROOT/'analysis/city_day.csv',parse_dates=['date']);bor=pd.read_csv(ROOT/'analysis/borough_summary.csv',index_col=0);models=pd.read_csv(ROOT/'analysis/weather_models.csv')
def finish(fig,name,source):
    fig.text(.07,.02,'范围：2025年6月1日至8月31日，纽约市。来源：'+source,fontsize=9,color='#555555')
    fig.tight_layout(rect=[0,.065,1,1]);fig.savefig(OUT/(name+'.png'));fig.savefig(OUT/(name+'.svg'));plt.close(fig)

fig,ax=plt.subplots(figsize=(11.5,5.6))
ax.plot(city.date,city.fhv_trips_index,label='网约车出行',color=blue,lw=1.8)
ax.plot(city.date,city.rail_entries_index,label='轨道与缆车入站',color=orange,lw=1.8)
ax.axhline(100,color='#888888',ls='--',lw=.7);ax.set_ylim(bottom=0)
ax.set_title('三个月内两类客流是否同步变化？',loc='left',pad=20)
ax.set_ylabel('日数量指数  各自期间日均值 = 100');ax.legend(frameon=False,ncol=2);ax.grid(axis='y',alpha=.2)
finish(fig,'01_daily_demand','TLC 高运量网约车逐笔记录、MTA 小时客流')

weekday=pd.read_csv(ROOT/'analysis/weekday_summary.csv')
fig,axs=plt.subplots(1,2,figsize=(11.5,5.6))
x=np.arange(7);labels=['周一','周二','周三','周四','周五','周六','周日']
axs[0].plot(x,weekday.fhv_trips/10000,'o-',color=blue,label='网约车出行');axs[0].plot(x,weekday.rail_entries/10000,'o-',color=orange,label='轨道与缆车入站')
axs[0].set_ylabel('日均数量  万次');axs[0].set_ylim(bottom=0);axs[0].legend(frameon=False)
axs[1].bar(x,weekday.mean_base_fare,color=green);axs[1].set_ylabel('平均每单基础车费  美元');axs[1].set_ylim(bottom=0)
for ax in axs:ax.set_xticks(x,labels);ax.grid(axis='y',alpha=.2)
fig.suptitle('一周中的客流和基础车费如何变化？',x=.07,ha='left',y=.99)
finish(fig,'02_weekday','TLC、MTA；基础车费不含税费、小费及附加费')

fig,ax=plt.subplots(figsize=(11.5,5.2))
row_names=['网约车出行次数','轨道与缆车入站人次','网约车平均基础车费']
for i,r in models.iterrows():
    ax.plot([r.rain_per10mm_low_pct,r.rain_per10mm_high_pct],[2-i]*2,color=blue,lw=2)
    ax.scatter(r.rain_per10mm_pct,2-i,color=blue,s=55,zorder=3)
ax.axvline(0,color='#555555',ls='--',lw=1);ax.set_yticks([2,1,0],row_names);ax.set_ylim(-.5,2.5)
ax.set_xlabel('日降水增加10毫米对应的条件关联  %  线段为95%区间')
ax.set_title('降雨与客流和基础车费有何关联？',loc='left',pad=18);ax.grid(axis='x',alpha=.2)
ax.text(.01,-.24,'控制温度、星期和月份；92个城市日；7日区块自助法。区间不能解释为因果效应。',transform=ax.transAxes,fontsize=10)
finish(fig,'03_rain_association','TLC、MTA、Open-Meteo 提供的 ERA5 再分析')

fig,ax=plt.subplots(figsize=(11.5,5.5));b=bor.sort_values('daily_rail_per1000',ascending=False);x=np.arange(len(b));w=.36
ax.bar(x-w/2,b.daily_fhv_per1000,w,label='网约车出行',color=blue);ax.bar(x+w/2,b.daily_rail_per1000,w,label='轨道与缆车入站',color=orange)
ax.set_xticks(x,[cn[v] for v in b.index]);ax.set_ylabel('每日每千名常住人口对应的区域出行次数');ax.set_ylim(bottom=0);ax.legend(frameon=False);ax.grid(axis='y',alpha=.2)
ax.set_title('人口规模校正后区域差异有多大？',loc='left',pad=18)
finish(fig,'04_borough_intensity','TLC、MTA、美国人口普查局 2024 年人口估计；包含通勤者与游客出行')

geo=json.loads((ROOT/'data/cleaned/borough_boundaries.geojson').read_text())
fig,axs=plt.subplots(1,2,figsize=(11.5,6.2));palettes=['Blues','Oranges']
for ax,key,cmapname,subtitle in zip(axs,['daily_fhv_per1000','daily_rail_per1000'],palettes,['网约车出行','轨道与缆车入站']):
    cmap=plt.get_cmap(cmapname);norm=colors.Normalize(vmin=0,vmax=float(bor[key].max()))
    for f in geo['features']:
        name=f['properties']['borough'];g=f['geometry'];polygons=g['coordinates'] if g['type']=='MultiPolygon' else [g['coordinates']]
        for p in polygons:ax.add_patch(Polygon(p[0],facecolor=cmap(norm(bor.loc[name,key])),edgecolor='#666666',linewidth=.3))
    ax.set_xlim(-74.27,-73.69);ax.set_ylim(40.47,40.94);ax.set_aspect(1/np.cos(np.deg2rad(40.7)));ax.axis('off');ax.set_title(subtitle,fontsize=13)
    plt.colorbar(plt.cm.ScalarMappable(norm=norm,cmap=cmap),ax=ax,shrink=.65,label='日均次数 / 千名常住人口')
    centers={'Bronx':(-73.86,40.875),'Brooklyn':(-73.97,40.64),'Manhattan':(-73.98,40.78),'Queens':(-73.82,40.74),'Staten Island':(-74.15,40.58)}
    for name,(lon,lat) in centers.items():ax.text(lon,lat,cn[name],fontsize=9,ha='center',bbox=dict(facecolor='white',alpha=.75,edgecolor='none',pad=1))
fig.suptitle('两种出行方式的空间集中程度相同吗？',x=.07,ha='left')
finish(fig,'05_spatial','TLC、MTA、美国人口普查局人口估计及 2024 年县级边界；两图色标分别标注')

profiles=pd.read_csv(ROOT/'analysis/cluster_profiles.csv',index_col=0);keys=['fhv_trips','rail_entries','mean_base_fare','temperature_c','precipitation_mm']
mean=city[keys].mean();sd=city[keys].std(ddof=0);profile_z=(profiles[keys]-mean)/sd
fig,ax=plt.subplots(figsize=(11.5,5.5));lim=max(1,float(np.abs(profile_z.to_numpy()).max()));im=ax.imshow(profile_z,cmap='RdBu_r',vmin=-lim,vmax=lim,aspect='auto')
ax.set_xticks(range(5),['网约车出行','轨道与缆车入站','平均基础车费','平均温度','降水量'])
ax.set_yticks(range(len(profiles)),[f'类型 {i}  {int(r.days)}天' for i,r in profiles.iterrows()])
for y,row in enumerate(profile_z.to_numpy()):
    for x,value in enumerate(row):ax.text(x,y,f'{value:+.2f}',ha='center',va='center',color='white' if abs(value)>lim*.55 else '#111111')
fig.colorbar(im,ax=ax,label='画像均值相对全期均值的标准差');ax.set_title('真实观测日期能分成哪些出行类型？',loc='left',pad=20)
finish(fig,'06_cluster_profiles','TLC、MTA、ERA5；热图展示原量纲标准化画像，聚类计算另含对数变换')

# This requested lineage diagram is explanatory, not a simulated analytical result.
fig,ax=plt.subplots(figsize=(11.5,6));ax.set_xlim(0,10);ax.set_ylim(0,6);ax.axis('off')
items=[(0.2,4.7,2.7,.8,'TLC 网约车记录\n上车时间、起点区域、基础车费'),(0.2,3.35,2.7,.8,'MTA 小时客流\n车站、时刻、区域、入站人数'),(0.2,2,2.7,.8,'ERA5 天气再分析\n纽约当地日期、温度、降水'),(0.2,.65,2.7,.8,'Census 人口与边界\n县代码、人口、地理多边形'),(4,2.1,2.4,2,'区域 日期统一表\n\n时间按纽约当地日聚合\n区域名与县代码映射\n车站坐标落区核验'),(7.5,2.1,2.2,2,'共同分析\n\n时间变化与跨源关联\n天气条件关联\n区域比较与日期聚类')]
for x,y,w,h,label in items:
    ax.add_patch(Rectangle((x,y),w,h,facecolor='#F1F5F7',edgecolor='#71838F',lw=1));ax.text(x+w/2,y+h/2,label,ha='center',va='center',fontsize=10)
for y in [5.1,3.75,2.4,1.05]:ax.add_patch(FancyArrowPatch((2.95,y),(3.95,3.1),arrowstyle='->',mutation_scale=12,color='#627885'))
ax.add_patch(FancyArrowPatch((6.45,3.1),(7.45,3.1),arrowstyle='->',mutation_scale=12,color='#627885'))
ax.set_title('独立数据源如何连接到同一分析单元？',loc='left',pad=10)
finish(fig,'07_data_lineage','项目实际字段与处理规则；原始、清洗和融合层均保留')
fig,axs=plt.subplots(1,2,figsize=(11.5,5.8))
for ax,adjusted in zip(axs,[False,True]):
    x=city['fhv_trips_weekday_index' if adjusted else 'fhv_trips']/ (1 if adjusted else 10000)
    y=city['rail_entries_weekday_index' if adjusted else 'rail_entries']/ (1 if adjusted else 10000)
    weekend=city.weekday>=5
    for mask,label,color in [(~weekend,'周一至周五',blue),(weekend,'周末',orange)]:
        ax.scatter(x[mask],y[mask],s=25,alpha=.75,color=color,label=label)
    ax.set_title(('同星期均值标准化后' if adjusted else '原始城市日')+f'  r={x.corr(y):+.3f}',fontsize=12)
    ax.set_xlabel('网约车出行 '+('指数' if adjusted else '万次/日'))
    ax.set_ylabel('轨道与缆车入站 '+('指数' if adjusted else '万人次/日'))
    ax.set_xlim(left=0);ax.set_ylim(bottom=0);ax.grid(alpha=.2);ax.legend(frameon=False,fontsize=9)
fig.suptitle('星期规律为什么会改变两类客流的相关方向？',x=.07,ha='left',y=.99)
finish(fig,'08_cross_source_scatter','TLC、MTA；92个城市日；校正指数以各自同星期均值为100，不是因果估计')
print('Created 7 core analytical figures and 1 data-lineage diagram')
