"""County point-in-polygon validation using original Census WGS84 geometry."""
import csv,json,zipfile,io
from pathlib import Path
import shapefile
from shapely.geometry import shape,Point,mapping
ROOT=Path(__file__).parent
z=zipfile.ZipFile(ROOT/'data/raw/census/cb_2024_us_county_500k.zip')
def part(ext):return io.BytesIO(z.read(next(n for n in z.namelist() if n.endswith(ext))))
r=shapefile.Reader(shp=part('.shp'),shx=part('.shx'),dbf=part('.dbf'),encoding='utf-8')
names=[x[0] for x in r.fields[1:]]
codes={'36005':'Bronx','36047':'Brooklyn','36061':'Manhattan','36081':'Queens','36085':'Staten Island'}
geo=[]
for sr in r.iterShapeRecords():
    rec=dict(zip(names,sr.record));key=rec.get('GEOID')
    if key in codes:geo.append({'type':'Feature','properties':{'borough':codes[key],'geoid':key},'geometry':sr.shape.__geo_interface__})
assert len(geo)==5
(ROOT/'data/cleaned/borough_boundaries.geojson').write_text(json.dumps({'type':'FeatureCollection','features':geo}),encoding='utf-8')
polys=[(g['properties']['borough'],shape(g['geometry'])) for g in geo]
rows=list(csv.DictReader((ROOT/'data/cleaned/mta_stations.csv').open(encoding='utf-8')))
results=[]
for row in rows:
    p=Point(float(row['longitude']),float(row['latitude']))
    matches=[n for n,g in polys if g.covers(p)]
    status='matched' if matches==[row['borough']] else 'boundary_or_water_unmatched' if not matches else 'disagrees'
    results.append({**row,'county_borough':'|'.join(matches),'spatial_validation':status})
with (ROOT/'data/cleaned/station_spatial_validation.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(results[0]));w.writeheader();w.writerows(results)
summary={'station_coordinate_records':len(results),'matched':sum(r['spatial_validation']=='matched' for r in results),
         'unmatched':sum(r['spatial_validation']=='boundary_or_water_unmatched' for r in results),
         'disagrees':sum(r['spatial_validation']=='disagrees' for r in results),
         'policy':'Keep source borough labels for aggregate joins; flag cartographic-boundary mismatches for review, never force nearest polygon.',
         'geometry':'Census 2024 cartographic county boundaries, 1:500000, WGS84 longitude/latitude'}
(ROOT/'quality/spatial.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(summary)
