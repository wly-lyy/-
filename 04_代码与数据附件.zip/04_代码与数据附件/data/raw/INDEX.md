本目录含辅助原始文件和六份代表性业务样本；完整TLC/MTA主源数据未包含在教学附件中。
样本：每月TLC首100行、每月首日MTA首100行，确定性结构样本，不是随机抽样，也不冒充总体分布。
实际样本的行数、字节数和SHA-256见 ../../metadata/sample_inventory.csv；本机已下载95个完整主要源文件的来源及SHA-256见 ../../metadata/raw_manifest.csv。完整本机三层索引见 ../../metadata/layer_index.csv。
