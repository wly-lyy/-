本目录包含六份清洗后结构样本、规范化辅助表和完整的460行行政区日、11,040行行政区小时融合表。完整的TLC/MTA逐日Parquet分区未装入教学附件。
样本行数、字节数及校验值见 ../../metadata/sample_inventory.csv。完整本机三层索引见 ../../metadata/layer_index.csv。
