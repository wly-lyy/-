"""Public-source collection with byte/row checks and real timestamped logs."""
import argparse,concurrent.futures,csv,datetime as dt,gzip,hashlib,io,json,os,time,urllib.parse,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
RAW=ROOT/'data/raw';LOGS=ROOT/'logs';RAW.mkdir(parents=True,exist_ok=True);LOGS.mkdir(exist_ok=True)
def utc():return dt.datetime.now(dt.timezone.utc).isoformat()
def save_meta(path,meta):
    if path.exists():
        old=json.loads(path.read_text(encoding='utf-8'))
        history=path.parent/'history';history.mkdir(exist_ok=True)
        stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        (history/(path.stem+'_'+stamp+'.json')).write_text(json.dumps(old,ensure_ascii=False,indent=2),encoding='utf-8')
    path.write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
def download_file(source,url,filename):
    folder=RAW/source;folder.mkdir(exist_ok=True);path=folder/filename;mp=LOGS/(source+'_'+filename+'.json')
    if path.exists() and mp.exists() and json.loads(mp.read_text()).get('status')=='verified':return {'skip_verified':filename}
    meta={'source':source,'url':url,'path':str(path.relative_to(ROOT)),'started_at':utc(),'status':'started','requests':[]}
    try:
        with urllib.request.urlopen(urllib.request.Request(url,method='HEAD'),timeout=40) as r:
            expected=int(r.headers['Content-Length']);etag=r.headers.get('ETag');modified=r.headers.get('Last-Modified')
        meta.update(expected_bytes=expected,etag=etag,last_modified=modified)
        save_meta(mp,meta)
        # Standard HTTP Range is used only on documented publicly downloadable files.
        partial=path.with_suffix(path.suffix+'.partial')
        with partial.open('wb') as f:
            for start in range(0,expected,8*1024*1024):
                end=min(start+8*1024*1024,expected)-1
                for attempt in range(3):
                    try:
                        with urllib.request.urlopen(urllib.request.Request(url,headers={'Range':f'bytes={start}-{end}'}),timeout=60) as r:
                            body=r.read();status=r.status;cr=r.headers.get('Content-Range')
                        if status==200 and start==0 and len(body)==expected:
                            f.write(body);meta['requests'].append({'at':utc(),'bytes':len(body),'mode':'whole'});break
                        if status!=206 or cr!=f'bytes {start}-{end}/{expected}' or len(body)!=end-start+1:raise ValueError('Incomplete or incorrect range')
                        f.write(body);meta['requests'].append({'at':utc(),'start':start,'end':end,'bytes':len(body)});break
                    except Exception as exc:
                        if attempt==2:raise
                        time.sleep(2**attempt)
                if status==200:break
                if end==expected-1 or start//(8*1024*1024)%10==0:print(source,filename,f'{end+1}/{expected}',flush=True)
                time.sleep(.15)
        if partial.stat().st_size!=expected:raise ValueError('Size mismatch')
        h=hashlib.sha256()
        with partial.open('rb') as f:
            for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
        if filename.endswith('.parquet'):
            with partial.open('rb') as f:
                assert f.read(4)==b'PAR1';f.seek(-4,2);assert f.read()==b'PAR1'
        partial.replace(path)
        meta.update(status='verified',bytes=expected,sha256=h.hexdigest(),completed_at=utc())
    except Exception as exc:meta.update(status='failed',error=f'{type(exc).__name__}: {exc}',failed_at=utc())
    save_meta(mp,meta);print(source,filename,meta['status'],flush=True);return meta

def mta_day(day,expected_rows):
    folder=RAW/'mta';folder.mkdir(exist_ok=True);path=folder/(day+'.csv');mp=LOGS/('mta_'+day+'.json')
    if path.exists() and mp.exists() and json.loads(mp.read_text()).get('status')=='verified':return {'skip_verified':day}
    end=(dt.date.fromisoformat(day)+dt.timedelta(days=1)).isoformat()
    query={'$where':f"transit_timestamp >= '{day}T00:00:00' AND transit_timestamp < '{end}T00:00:00'",'$limit':200000}
    url='https://data.ny.gov/resource/5wq4-mkjj.csv?'+urllib.parse.urlencode(query)
    meta={'source':'mta','url':url,'path':str(path.relative_to(ROOT)),'started_at':utc(),'expected_rows':expected_rows}
    try:
        if expected_rows>200000:raise ValueError('Daily row limit insufficient')
        with urllib.request.urlopen(urllib.request.Request(url,headers={'Accept-Encoding':'gzip'}),timeout=180) as response:
            transferred=response.read();encoding=response.headers.get('Content-Encoding','identity')
        body=gzip.decompress(transferred) if encoding=='gzip' else transferred
        meta.update(http_content_encoding=encoding,transfer_bytes=len(transferred),stored_format='Canonical CSV response body after standard HTTP content decoding, no reformatting')
        if not body.startswith(b'"transit_timestamp"') and not body.startswith(b'transit_timestamp'):raise ValueError('Not expected CSV')
        rows=sum(1 for row in csv.reader(io.StringIO(body.decode('utf-8'))))-1
        if rows!=expected_rows:raise ValueError(f'Expected {expected_rows}, got {rows}')
        path.write_bytes(body)
        meta.update(status='verified',bytes=len(body),rows=rows,sha256=hashlib.sha256(body).hexdigest(),completed_at=utc())
    except Exception as exc:meta.update(status='failed',error=f'{type(exc).__name__}: {exc}',failed_at=utc())
    save_meta(mp,meta);print('mta',day,meta.get('rows'),meta.get('bytes'),meta['status'],flush=True);time.sleep(.7);return meta

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['tlc','mta','mta_test']);a=ap.parse_args()
    if a.mode=='tlc':
        jobs=[('tlc',f'https://d37ci6vzurychx.cloudfront.net/trip-data/fhvhv_tripdata_2025-{m}.parquet',f'fhvhv_tripdata_2025-{m}.parquet') for m in ['06','07','08']]
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(lambda x:download_file(*x),jobs))
    else:
        counts=json.loads((ROOT/'docs/mta_daycounts.json').read_text())
        if a.mode=='mta_test':counts=counts[:1]
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:list(ex.map(lambda x:mta_day(x['day'][:10],int(x['n'])),counts))
