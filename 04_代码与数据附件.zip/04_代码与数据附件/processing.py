"""Rebuild cleaned layers and borough-day/hour source tables from verified raw files."""
import argparse,csv,datetime as dt,json,shutil,sys,zipfile
from pathlib import Path
import duckdb
ROOT=Path(__file__).resolve().parent
for d in ['data/cleaned','data/integrated','quality','analysis','visualization','temp']:(ROOT/d).mkdir(parents=True,exist_ok=True)
conn=duckdb.connect(str(ROOT/'analysis/project.duckdb'))
conn.execute("SET memory_limit='3GB'; SET threads=4;")
conn.execute(f"SET temp_directory='{(ROOT/'temp').as_posix()}'")
conn.execute('SET preserve_insertion_order=false')
def path(p):return (ROOT/p).as_posix()
def csvout(sql,p):conn.execute(f"COPY ({sql}) TO '{path(p)}' (HEADER,DELIMITER ',')")
def getone(sql):
    c=conn.execute(sql);return dict(zip([x[0] for x in c.description],c.fetchone()))
def savedict(p,d):(ROOT/p).write_text(json.dumps(d,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
boroughs=['Bronx','Brooklyn','Manhattan','Queens','Staten Island']

def auxiliary():
    conn.execute(f"CREATE OR REPLACE TABLE zones AS SELECT * FROM read_csv('{path('data/raw/tlc/taxi_zone_lookup.csv')}',header=true)")
    assert conn.execute('SELECT count(*)=count(DISTINCT LocationID) FROM zones').fetchone()[0]
    popfile=ROOT/'data/raw/census/co-est2024-alldata.csv'
    rows=list(csv.DictReader(popfile.open(encoding='latin-1')))
    mapping={'005':'Bronx','047':'Brooklyn','061':'Manhattan','081':'Queens','085':'Staten Island'}
    cleaned=[]
    for r in rows:
        if r['STATE'].zfill(2)=='36' and r['COUNTY'].zfill(3) in mapping:
            cleaned.append({'county_fips':'36'+r['COUNTY'].zfill(3),'borough':mapping[r['COUNTY'].zfill(3)],'population_2024':int(r['POPESTIMATE2024'])})
    assert len(cleaned)==5
    with (ROOT/'data/cleaned/population.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(cleaned[0]));w.writeheader();w.writerows(cleaned)
    weather=json.loads((ROOT/'data/raw/weather/nyc_2025_summer.json').read_text(encoding='utf-8'))
    assert weather['timezone']=='America/New_York'
    day=weather['daily'];assert len(day['time'])==92 and len(set(day['time']))==92
    keys=list(day)
    with (ROOT/'data/cleaned/weather.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['date' if k=='time' else k for k in keys]);w.writerows(zip(*[day[k] for k in keys]))
    conn.execute(f"CREATE OR REPLACE TABLE population AS SELECT * FROM read_csv('{path('data/cleaned/population.csv')}',header=true)")
    conn.execute(f"CREATE OR REPLACE TABLE weather AS SELECT * FROM read_csv('{path('data/cleaned/weather.csv')}',header=true)")
    csvout('SELECT * FROM zones','data/cleaned/zones.csv')
    savedict('quality/auxiliary.json',{'population_rows':5,'weather_rows':92,'weather_units':weather['daily_units'],
        'weather_nulls':{k:sum(v is None for v in day[k]) for k in keys},
        'population_vintage':'2024 estimates, available before June 2025','weather_note':'ERA5 reanalysis at Central Park coordinate, city-wide daily exposure proxy',
        'timezone':'America/New_York','zone_mapping_unique':True})

def mta(partial=False):
    files=sorted((ROOT/'data/raw/mta').glob('*.csv'))
    if not partial:assert len(files)==92,f'Expected 92 MTA daily files; got {len(files)}'
    stats=[]
    for p in files:
        out=ROOT/'data/cleaned/mta'/f'{p.stem}.parquet';out.parent.mkdir(exist_ok=True)
        qpath=ROOT/'quality'/f'mta_{p.stem}.json'
        if out.exists() and qpath.exists():stats.append(json.loads(qpath.read_text()));continue
        conn.execute(f"CREATE OR REPLACE TEMP TABLE m0 AS SELECT * FROM read_csv('{p.as_posix()}',header=true,sample_size=-1)")
        raw=conn.execute('SELECT count(*) FROM m0').fetchone()[0]
        conn.execute('CREATE OR REPLACE TEMP TABLE m1 AS SELECT DISTINCT * FROM m0')
        unique=conn.execute('SELECT count(*) FROM m1').fetchone()[0]
        # Non-subway modes are retained as separately identified rail/tram modes, not relabelled subway.
        invalid="transit_timestamp IS NULL OR station_complex_id IS NULL OR ridership IS NULL OR NOT isfinite(ridership::DOUBLE) OR ridership<0 OR borough NOT IN ('Bronx','Brooklyn','Manhattan','Queens','Staten Island')"
        quality=getone(f"SELECT count(*) AS distinct_rows,count(*) FILTER (WHERE {invalid}) AS invalid_rows,count(*) FILTER (WHERE transfers>ridership) AS transfers_gt_ridership,count(*) FILTER (WHERE latitude IS NULL OR longitude IS NULL) AS missing_coordinates FROM m1")
        quality.update(date=p.stem,raw_rows=raw,exact_duplicates_removed=raw-unique)
        conn.execute(f"COPY (SELECT * FROM m1 WHERE NOT ({invalid})) TO '{out.as_posix()}' (FORMAT PARQUET,COMPRESSION ZSTD)")
        quality['cleaned_rows']=unique-quality['invalid_rows'];savedict(f'quality/mta_{p.stem}.json',quality);stats.append(quality)
    conn.execute(f"CREATE OR REPLACE VIEW mta_clean AS SELECT * FROM read_parquet('{path('data/cleaned/mta/*.parquet')}')")
    conn.execute("CREATE OR REPLACE TABLE mta_hour AS SELECT transit_timestamp AS hour,borough,sum(ridership) AS rail_entries,sum(transfers) AS transfer_entries,count(DISTINCT station_complex_id) AS complexes FROM mta_clean GROUP BY ALL")
    conn.execute("CREATE OR REPLACE TABLE mta_day AS SELECT hour::DATE AS date,borough,sum(rail_entries) AS rail_entries,sum(transfer_entries) AS transfer_entries,count(*) AS observed_hours FROM mta_hour GROUP BY ALL")
    conn.execute("CREATE OR REPLACE TABLE stations AS SELECT station_complex_id,station_complex,borough,transit_mode,latitude,longitude,count(*) AS rows_observed,sum(ridership) AS entries FROM mta_clean GROUP BY ALL")
    csvout('SELECT * FROM mta_day ORDER BY date,borough','data/cleaned/mta_borough_day.csv')
    csvout('SELECT * FROM stations ORDER BY station_complex_id','data/cleaned/mta_stations.csv')
    csvout('SELECT transit_mode,sum(ridership) AS entries,count(*) AS records FROM mta_clean GROUP BY ALL','quality/mta_modes.csv')
    # Natural-key conflicts require review; same key rows cannot silently multiply a join.
    keys='transit_timestamp,transit_mode,station_complex_id,payment_method,fare_class_category'
    conflicts=getone(f'SELECT count(*) AS conflicting_keys,sum(n-1) AS extra_rows FROM (SELECT {keys},count(*) n FROM mta_clean GROUP BY ALL HAVING n>1)')
    savedict('quality/mta_summary.json',{'days_loaded':len(files),'raw_rows':sum(x['raw_rows'] for x in stats),'cleaned_rows':sum(x['cleaned_rows'] for x in stats),'exact_duplicates_removed':sum(x['exact_duplicates_removed'] for x in stats),'invalid_rows':sum(x['invalid_rows'] for x in stats),'natural_key_conflicts':conflicts})
    print('MTA processed',len(files),'days',flush=True)

def tlc():
    auxiliary()
    for month in ['06','07','08']:
        p=ROOT/'data/raw/tlc'/f'fhvhv_tripdata_2025-{month}.parquet';assert p.exists(),p
        out=ROOT/'data/cleaned/tlc'/f'2025-{month}.parquet';out.parent.mkdir(exist_ok=True)
        if out.exists() and (ROOT/'quality'/f'tlc_{month}.json').exists():continue
        conn.execute(f"CREATE OR REPLACE VIEW t0 AS SELECT * FROM read_parquet('{p.as_posix()}')")
        invalid_time="pickup_datetime IS NULL OR pickup_datetime < TIMESTAMP '2025-06-01' OR pickup_datetime >= TIMESTAMP '2025-09-01' OR dropoff_datetime IS NULL OR dropoff_datetime<pickup_datetime OR trip_time IS NULL OR trip_time<=0"
        invalid_spatial="z.Borough IS NULL OR z.Borough NOT IN ('Bronx','Brooklyn','Manhattan','Queens','Staten Island')"
        fare_valid="base_passenger_fare IS NOT NULL AND isfinite(base_passenger_fare) AND base_passenger_fare>=0"
        quality=getone(f"SELECT count(*) AS raw_rows,count(*) FILTER (WHERE {invalid_time}) AS invalid_time,count(*) FILTER (WHERE NOT ({invalid_time}) AND ({invalid_spatial})) AS invalid_origin_after_time,count(*) FILTER (WHERE NOT ({invalid_time}) AND NOT ({invalid_spatial}) AND NOT ({fare_valid})) AS invalid_fare_in_kept_trips,count(*) FILTER (WHERE trip_miles IS NULL OR trip_miles<0) AS missing_or_negative_distance,count(*) FILTER (WHERE base_passenger_fare>1000) AS fare_gt_1000_flag,count(*) FILTER (WHERE trip_time>21600) AS duration_gt_6h_flag FROM t0 t LEFT JOIN zones z ON t.PULocationID=z.LocationID")
        # Trip IDs are absent. Potential duplicate signatures are audited, never automatically erased as if unique IDs existed.
        signature='hvfhs_license_num,pickup_datetime,dropoff_datetime,PULocationID,DOLocationID,trip_time,trip_miles,base_passenger_fare'
        dup=getone(f'SELECT count(*) AS repeated_signatures,coalesce(sum(n-1),0) AS extra_signature_rows FROM (SELECT {signature},count(*) n FROM t0 GROUP BY ALL HAVING n>1)')
        quality['potential_duplicate_signature_audit']=dup
        conn.execute(f"COPY (SELECT t.*,z.Borough AS borough,z.Zone AS origin_zone,({fare_valid}) AS fare_valid FROM t0 t LEFT JOIN zones z ON t.PULocationID=z.LocationID WHERE NOT ({invalid_time}) AND NOT ({invalid_spatial})) TO '{out.as_posix()}' (FORMAT PARQUET,COMPRESSION ZSTD)")
        quality['cleaned_trip_rows']=quality['raw_rows']-quality['invalid_time']-quality['invalid_origin_after_time']
        quality['zero_fares_retained']=True;quality['unidentified_duplicate_policy']='Retain potential duplicates because no unique trip identifier is provided; report repeated signatures and do not claim these are duplicate orders.'
        savedict(f'quality/tlc_{month}.json',quality);print('TLC cleaned',month,quality,flush=True)
    conn.execute(f"CREATE OR REPLACE VIEW tlc_clean AS SELECT * FROM read_parquet('{path('data/cleaned/tlc/*.parquet')}')")
    conn.execute("CREATE OR REPLACE TABLE tlc_hour AS SELECT date_trunc('hour',pickup_datetime) AS hour,borough,count(*) AS fhv_trips,count(*) FILTER(WHERE fare_valid) AS fare_trips,sum(base_passenger_fare) FILTER(WHERE fare_valid) AS base_fare_usd,avg(base_passenger_fare) FILTER(WHERE fare_valid) AS mean_base_fare,median(base_passenger_fare) FILTER(WHERE fare_valid) AS median_base_fare FROM tlc_clean GROUP BY ALL")
    conn.execute("CREATE OR REPLACE TABLE tlc_day AS SELECT pickup_datetime::DATE AS date,borough,count(*) AS fhv_trips,count(*) FILTER(WHERE fare_valid) AS fare_trips,sum(base_passenger_fare) FILTER(WHERE fare_valid) AS base_fare_usd,avg(base_passenger_fare) FILTER(WHERE fare_valid) AS mean_base_fare,median(base_passenger_fare) FILTER(WHERE fare_valid) AS median_base_fare,avg(trip_miles) FILTER(WHERE trip_miles>=0 AND isfinite(trip_miles)) AS mean_miles,avg(trip_time)/60 AS mean_minutes,avg(base_passenger_fare) FILTER(WHERE fare_valid AND base_passenger_fare<=1000) AS mean_fare_le1000 FROM tlc_clean GROUP BY ALL")
    csvout('SELECT * FROM tlc_day ORDER BY date,borough','data/cleaned/tlc_borough_day.csv')
    csvout('SELECT PULocationID,count(*) AS trips,sum(base_passenger_fare) FILTER(WHERE fare_valid) AS base_fare_usd FROM tlc_clean GROUP BY ALL','data/cleaned/tlc_zone_totals.csv')
    savedict('quality/tlc_summary.json',getone('SELECT count(*) AS cleaned_trip_rows,count(*) FILTER(WHERE fare_valid) AS fare_rows,min(pickup_datetime) AS start_time,max(pickup_datetime) AS end_time,quantile_cont(base_passenger_fare,[0.5,0.9,0.99,0.999]) FILTER(WHERE fare_valid) AS fare_quantiles FROM tlc_clean'))

def integrate():
    auxiliary()
    conn.execute("CREATE OR REPLACE TABLE integrated_day AS SELECT t.*,m.rail_entries,m.transfer_entries,m.observed_hours,w.temperature_2m_mean,w.temperature_2m_max,w.precipitation_sum,w.wind_speed_10m_max,p.population_2024,1000.0*t.fhv_trips/p.population_2024 AS fhv_trips_per_1000_residents,1000.0*m.rail_entries/p.population_2024 AS rail_entries_per_1000_residents,dayofweek(t.date) AS weekday,month(t.date) AS month FROM tlc_day t LEFT JOIN mta_day m USING(date,borough) LEFT JOIN weather w USING(date) LEFT JOIN population p USING(borough)")
    assert conn.execute('SELECT count(*) FROM integrated_day').fetchone()[0]==460
    assert conn.execute('SELECT count(*) FROM (SELECT date,borough,count(*) n FROM integrated_day GROUP BY ALL HAVING n>1)').fetchone()[0]==0
    quality=getone('SELECT count(*) AS rows,count(DISTINCT date) AS dates,count(DISTINCT borough) AS boroughs,count(*) FILTER(WHERE rail_entries IS NULL) AS missing_mta,count(*) FILTER(WHERE precipitation_sum IS NULL) AS missing_weather,count(*) FILTER(WHERE population_2024 IS NULL) AS missing_population,sum(fhv_trips) AS fhv_trips,sum(rail_entries) AS rail_entries FROM integrated_day')
    assert quality['missing_mta']==quality['missing_weather']==quality['missing_population']==0,quality
    csvout('SELECT * FROM integrated_day ORDER BY date,borough','data/integrated/borough_day.csv')
    csvout('SELECT t.*,m.rail_entries FROM tlc_hour t LEFT JOIN mta_hour m USING(hour,borough) ORDER BY hour,borough','data/integrated/borough_hour.csv')
    savedict('quality/integration.json',quality)
    print('Integrated',quality,flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['auxiliary','mta','mta_partial','tlc','integrate']);a=ap.parse_args()
    if a.mode=='mta_partial':mta(True)
    else:globals()[a.mode]()
