"""Additional observed-data descriptions and specification diagnostics."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parent
c=pd.read_csv(R/'analysis/city_day.csv',parse_dates=['date'])
keys=['fhv_trips','rail_entries','mean_base_fare','temperature_c','precipitation_mm']
c[keys].describe(percentiles=[.25,.5,.75,.9]).T.to_csv(R/'analysis/descriptive_statistics.csv')
controls=pd.get_dummies(c[['weekday','month']].astype('category'),drop_first=True,dtype=float)
X=np.column_stack([np.ones(len(c)),c.precipitation_mm/10,c.temperature_c,controls.to_numpy()])
rows=[];coeff=[]
for outcome in keys[:3]:
    y=np.log(c[outcome].to_numpy());b=np.linalg.lstsq(X,y,rcond=None)[0];res=y-X@b
    coeff.extend({'outcome':outcome,'term':term,'coefficient':float(v)} for term,v in zip(['intercept','precipitation_per10mm','temperature_c']+list(controls.columns),b))
    leave=[]
    for i in range(len(c)):
        take=np.arange(len(c))!=i;leave.append(100*np.expm1(np.linalg.lstsq(X[take],y[take],rcond=None)[0][1]))
    for block in [3,7,14]:
        rng=np.random.default_rng(20251112);draws=[]
        for _ in range(2000):
            starts=rng.integers(0,len(c),int(np.ceil(len(c)/block)))
            idx=np.concatenate([(np.arange(s,s+block)%len(c)) for s in starts])[:len(c)]
            if np.linalg.matrix_rank(X[idx])<X.shape[1]:continue
            draws.append(np.linalg.lstsq(X[idx],y[idx],rcond=None)[0][1])
        lo,hi=100*np.expm1(np.quantile(draws,[.025,.975]))
        rows.append({'outcome':outcome,'block_days':block,'rain_pct':100*np.expm1(b[1]),'ci_low_pct':lo,'ci_high_pct':hi,'valid_bootstraps':len(draws),'residual_lag1_correlation':np.corrcoef(res[:-1],res[1:])[0,1],'leave_one_day_out_min_pct':min(leave),'leave_one_day_out_max_pct':max(leave)})
pd.DataFrame(rows).to_csv(R/'analysis/model_diagnostics.csv',index=False)
pd.DataFrame(coeff).to_csv(R/'analysis/model_coefficients.csv',index=False)
info={'n_days':len(c),'weather_design_columns':X.shape[1],'weather_design_rank':int(np.linalg.matrix_rank(X)),'rain_ge1mm_days':int((c.precipitation_mm>=1).sum()),'rain_max_mm':float(c.precipitation_mm.max()),'rain_max_date':str(c.loc[c.precipitation_mm.idxmax(),'date'].date()),'purpose':'Supplementary block-length sensitivity and leave-one-date-out range, added during final review; no causal claim. All three chosen block lengths are reported.'}
(R/'analysis/diagnostics.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
print(pd.DataFrame(rows).to_string(index=False))
