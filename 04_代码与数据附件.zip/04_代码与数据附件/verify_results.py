"""Independent invariants and raw-slice checks; records actual results only."""
from pathlib import Path
import json,datetime as dt
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
d=pd.read_csv(ROOT/'data/integrated/borough_day.csv');c=pd.read_csv(ROOT/'analysis/city_day.csv');h=pd.read_csv(ROOT/'data/integrated/borough_hour.csv')
r=json.loads((ROOT/'analysis/results.json').read_text(encoding='utf-8'))
checks={}
def check(name,value):
    checks[name]=bool(value)
    if not value:raise AssertionError(name)
check('exactly_92_dates_x_5_boroughs',len(d)==460 and d.date.nunique()==92 and d.borough.nunique()==5 and not d[['date','borough']].duplicated().any())
check('no_missing_integrated_source_values',not d[['fhv_trips','rail_entries','precipitation_sum','population_2024']].isna().any().any())
check('hours_unique_and_complete',len(h)==92*24*5 and not h[['hour','borough']].duplicated().any() and not h.rail_entries.isna().any())
check('day_and_hour_traffic_totals_agree',int(d.fhv_trips.sum())==int(h.fhv_trips.sum()) and np.isclose(d.rail_entries.sum(),h.rail_entries.sum()))
check('city_and_borough_totals_agree',int(c.fhv_trips.sum())==int(d.fhv_trips.sum())==r['fhv_trips'] and np.isclose(c.rail_entries.sum(),d.rail_entries.sum()))
check('weighted_fare_uses_valid_fare_rows',np.isclose(d.base_fare_usd.sum()/d.fare_trips.sum(),r['mean_base_fare']))
check('correlation_matches_independent_numpy',np.isclose(np.corrcoef(c.fhv_trips,c.rail_entries)[0,1],r['daily_raw_correlation']))
check('all_observed_dates_have_cluster',c.cluster.notna().all() and c.cluster.nunique()==r['selected_k'])
profiles=pd.read_csv(ROOT/'analysis/cluster_profiles.csv');check('cluster_profiles_reconcile',profiles.days.sum()==92)
models=pd.read_csv(ROOT/'analysis/weather_models.csv');check('weather_sample_not_pseudoreplicated',(models.n_days==92).all())
check('bootstrap_counts_valid',((models.bootstrap_valid>1900)&(models.bootstrap_valid<=2000)).all())
extra={'raw_slice_check':'not run: complete raw files not present'}
raw=ROOT/'data/raw/tlc/fhvhv_tripdata_2025-06.parquet'
full_raw_available=raw.exists() and (ROOT/'data/raw/mta/2025-06-16.csv').exists()
if full_raw_available:
    import duckdb
    con=duckdb.connect();con.execute("SET memory_limit='1GB'")
    rows=con.execute(f"SELECT z.Borough,count(*),sum(t.base_passenger_fare) FILTER(WHERE t.base_passenger_fare>=0 AND isfinite(t.base_passenger_fare)) FROM read_parquet('{raw.as_posix()}') t JOIN read_csv('{(ROOT/'data/raw/tlc/taxi_zone_lookup.csv').as_posix()}') z ON t.PULocationID=z.LocationID WHERE t.pickup_datetime>=TIMESTAMP '2025-06-16' AND t.pickup_datetime<TIMESTAMP '2025-06-17' AND t.dropoff_datetime>=t.pickup_datetime AND t.trip_time>0 AND z.Borough IN ('Bronx','Brooklyn','Manhattan','Queens','Staten Island') GROUP BY 1").fetchall()
    day=d[d.date=='2025-06-16'].set_index('borough')
    check('raw_tlc_june16_matches_integrated',all(day.loc[b,'fhv_trips']==n and np.isclose(day.loc[b,'base_fare_usd'],fare,atol=.01) for b,n,fare in rows))
    raw_mta=pd.read_csv(ROOT/'data/raw/mta/2025-06-16.csv')
    actual=raw_mta.drop_duplicates().groupby('borough').ridership.sum()
    check('raw_mta_june16_matches_integrated',all(np.isclose(day.loc[b,'rail_entries'],v) for b,v in actual.items()))
    extra={'raw_slice_check':'2025-06-16, 5 boroughs; independently re-aggregated raw TLC and MTA'}
result={'verified_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'checks':checks,**extra,'all_passed':all(checks.values())}
output_name='result_verification.json' if full_raw_available else 'lightweight_verification.json'
(ROOT/'quality'/output_name).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
